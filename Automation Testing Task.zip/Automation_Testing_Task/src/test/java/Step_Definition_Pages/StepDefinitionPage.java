package Step_Definition_Pages;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import project_object_model_pages.P4CoursesFillInfo;
import project_object_model_pages.P3CoursesPage;
import project_object_model_pages.P1LoginPage;
import project_object_model_pages.P2WebsitePage;

public class StepDefinitionPage {
    P1LoginPage login=new P1LoginPage();
    P2WebsitePage web=new P2WebsitePage();
    P3CoursesPage course_page=new P3CoursesPage();
    P4CoursesFillInfo course_info=new P4CoursesFillInfo();

    @Given("user sign in with username and password")
    public void Signin ()
    {
        login.usernameEl().sendKeys("testregister@aaa.com");
        login.passEl().sendKeys("Wakram_123");
    }
    @And("user click on login button and login successfully")
    public void loginButton (){
        login.loginButton().click();
    }
    @And("user open courses Page from left side navigation bar")
    public void coursesPage () {
        web.navigationBar().click();
        web.courses().click();
    }

    @When("user click on add course button")
    public void courseButton () throws InterruptedException {
        course_page.addCourseButton().click();
        Thread.sleep(1000);
    }

    @And("user should be able to fill course basic info")
    public void courseInfo ()
    {
        course_info.courseName().sendKeys("ITworkx");
        course_info.SubjectEl().click();
        course_info.GradeEl().click();
        course_info.TeachermarkEl().click();
        course_info.TeacherEl().click();
        course_info.teacherChoice().click();
        course_info.teacherChoice().sendKeys(Keys.ENTER);

    }
    @And("click on create button")
    public void createButton () throws InterruptedException {

        course_info.CreationButton().click();
        Thread.sleep(500);
    }

    @Then("user should be able to back to courses list page and the course title should display")
    public void Back_to_Courses_Page ()
    {
        web.navigationBar().click();
        web.courses().click();
    }





}
