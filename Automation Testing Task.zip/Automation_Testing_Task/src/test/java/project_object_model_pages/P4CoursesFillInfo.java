package project_object_model_pages;

import Step_Definition_Pages.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P4CoursesFillInfo {
    public WebElement courseName()
    {
        return Hooks.driver.findElement(By.id("txtCourseName"));
    }
    public WebElement SubjectEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[label=\"Language Arts\"]"));
    }
    public WebElement GradeEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[label=\"3\"]"));
    }
    public WebElement TeacherEl()
    {
        return Hooks.driver.findElement(By.cssSelector("i[role=\"button\"]"));
    }
    public WebElement TeachermarkEl()
    {
        return Hooks.driver.findElement(By.id("lblGetSelectedSubjectTeachers"));
    }
    public WebElement teacherChoice()
    {
        return Hooks.driver.findElement(By.cssSelector("input[type=\"search\"]"));
    }


    public WebElement CreationButton()
    {
        return Hooks.driver.findElement(By.id("btnSaveAsDraftCourse"));
    }

}
