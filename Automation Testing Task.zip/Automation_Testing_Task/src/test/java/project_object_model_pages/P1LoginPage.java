package project_object_model_pages;

import Step_Definition_Pages.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P1LoginPage {
    public WebElement usernameEl()
    {
        return Hooks.driver.findElement(By.id("Email"));
    }

    public WebElement passEl()
    {
        return Hooks.driver.findElement(By.id("inputPassword"));
    }

    public WebElement loginButton()
    {
        return Hooks.driver.findElement(By.id("btnLogin"));
    }

}
