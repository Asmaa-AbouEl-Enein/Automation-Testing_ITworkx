package project_object_model_pages;

import Step_Definition_Pages.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P3CoursesPage {
    public WebElement addCourseButton()
    {
        return Hooks.driver.findElement(By.id("btnListAddCourse"));
    }
    public WebElement courseSortingEl()
    {
        return Hooks.driver.findElement(By.cssSelector("select > option[value=\"3\"]"));

    }

    public WebElement displayed()
    {
        return Hooks.driver.findElement(By.cssSelector("a[title=\"ITworkx\"]"));
    }
}
