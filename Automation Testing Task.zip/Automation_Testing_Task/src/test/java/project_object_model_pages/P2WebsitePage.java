package project_object_model_pages;
import Step_Definition_Pages.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P2WebsitePage {
    public WebElement navigationBar()
    {
        return Hooks.driver.findElement(By.id("btnMinifyMe"));
    }

    public WebElement courses()
    {
        return Hooks.driver.findElement(By.id("btnMyCoursesList"));
    }
}
